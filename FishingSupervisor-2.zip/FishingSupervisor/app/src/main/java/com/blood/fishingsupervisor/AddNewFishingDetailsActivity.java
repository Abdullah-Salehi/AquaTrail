package com.blood.fishingsupervisor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddNewFishingDetailsActivity extends AppCompatActivity {

    private EditText employeeIdEt, activityIdEt, fishingLocationEt, fishingTimeEt, fishingDateEt,
            fishingMethodEt, fishingVesselIdEt, fishingCrewEt, catchWeightEt, catchSpeciesEt, orderIdEt;
    private Button submitBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_fishing_details);

        employeeIdEt = findViewById(R.id.employee_id_et);
        activityIdEt = findViewById(R.id.activity_id_et);
        fishingLocationEt = findViewById(R.id.fishing_location_et);
        fishingTimeEt = findViewById(R.id.fishing_time_et);
        fishingDateEt = findViewById(R.id.fishing_date_et);
        fishingMethodEt = findViewById(R.id.fishing_method_et);
        fishingVesselIdEt = findViewById(R.id.fishing_vessel_id_et);
        fishingCrewEt = findViewById(R.id.fishing_crew_et);
        catchWeightEt = findViewById(R.id.catch_weight_et);
        catchSpeciesEt = findViewById(R.id.catch_species_et);
        orderIdEt = findViewById(R.id.order_id_et);
        submitBtn = findViewById(R.id.submit_btn);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String employeeId = employeeIdEt.getText().toString();
                String activityId = activityIdEt.getText().toString();
                String fishingLocation = fishingLocationEt.getText().toString();
                String fishingTime = fishingTimeEt.getText().toString();
                String fishingDate = fishingDateEt.getText().toString();
                String fishingMethod = fishingMethodEt.getText().toString();
                String fishingVesselId = fishingVesselIdEt.getText().toString();
                String fishingCrew = fishingCrewEt.getText().toString();
                String catchWeight = catchWeightEt.getText().toString();
                String catchSpecies = catchSpeciesEt.getText().toString();
                String orderId = orderIdEt.getText().toString();



                if(employeeId.isEmpty() || activityId.isEmpty() || fishingLocation.isEmpty() || fishingTime.isEmpty() || fishingDate.isEmpty() || fishingMethod.isEmpty() || fishingVesselId.isEmpty() || fishingCrew.isEmpty() || catchWeight.isEmpty() || catchSpecies.isEmpty() || orderId.isEmpty()) {
                    showToast("Please fill in all fields.");
                    return;
                }else {
                    showToast("Success! Your fishing details have been submitted.");
                    finish();
                }
            }
        });
    }

    private void showToast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void notifySupervisor(String employeeId, String confirmationMessage) {
        // TODO: Implement supervisor notification functionality, such as sending an email or SMS.
        // This could be done using a third-party library or service, or by implementing it directly.
    }
}
