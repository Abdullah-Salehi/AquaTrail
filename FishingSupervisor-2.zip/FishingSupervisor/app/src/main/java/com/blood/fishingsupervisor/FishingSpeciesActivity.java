package com.blood.fishingsupervisor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class FishingSpeciesActivity extends AppCompatActivity {

    private ListView mFishingSpeciesListView;

    private String[] mFishingSpecies = {"Salmon", "Tuna", "Cod", "Haddock", "Trout", "Mackerel", "Sardine", "Herring", "Barramundi", "Grouper", "Mahi-mahi", "Swordfish", "Halibut", "Sole", "Perch", "Bass", "Catfish", "Pike", "Walleye", "Crappie"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fishing_species);

        mFishingSpeciesListView = findViewById(R.id.fishing_species_list_view);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mFishingSpecies);
        mFishingSpeciesListView.setAdapter(adapter);
    }
}
