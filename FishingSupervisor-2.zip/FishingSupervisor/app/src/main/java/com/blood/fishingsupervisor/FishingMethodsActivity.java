package com.blood.fishingsupervisor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class FishingMethodsActivity extends AppCompatActivity {

    private ListView mFishingMethodsListView;

    private String[] mFishingMethods = {"Handline fishing", "Trolling", "Pole and line fishing", "Gillnetting", "Longlining","Trap Fishing"};

    private Integer[] mFishingMethodImages = {R.drawable.headline, R.drawable.trolling, R.drawable.poleandline, R.drawable.gillnetting, R.drawable.longlinning,R.drawable.trap};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fishing_methods);

        mFishingMethodsListView = findViewById(R.id.fishing_methods_list_view);

        ArrayList<Item> items = new ArrayList<Item>();
        for(int i = 0; i < mFishingMethods.length; i++) {
            items.add(new Item(mFishingMethods[i], mFishingMethodImages[i]));
        }

        CustomAdapter adapter = new CustomAdapter(this, items);
        mFishingMethodsListView.setAdapter(adapter);
    }
}

