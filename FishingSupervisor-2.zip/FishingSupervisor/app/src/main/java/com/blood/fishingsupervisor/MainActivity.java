package com.blood.fishingsupervisor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity  {
    private Button newFishingDetailsBtn, fishingMethodsBtn, fishingLocationsBtn, fishingSpeciesBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newFishingDetailsBtn = findViewById(R.id.new_fishing_details_btn);
        fishingMethodsBtn = findViewById(R.id.fishing_methods_btn);
        fishingLocationsBtn = findViewById(R.id.fishing_locations_btn);
        fishingSpeciesBtn = findViewById(R.id.fishing_species_btn);

        newFishingDetailsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newFishingDetailsIntent = new Intent(MainActivity.this, AddNewFishingDetailsActivity.class);
                startActivity(newFishingDetailsIntent);
            }
        });
        fishingMethodsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fishingMethodsIntent = new Intent(MainActivity.this, FishingMethodsActivity.class);
                startActivity(fishingMethodsIntent);
            }
        });
        fishingLocationsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fishingLocationsIntent = new Intent(MainActivity.this, FishingLocationsActivity.class);
                startActivity(fishingLocationsIntent);
            }
        });
        fishingSpeciesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent fishingSpeciesIntent = new Intent(MainActivity.this, FishingSpeciesActivity.class);
                startActivity(fishingSpeciesIntent);
            }
        });
    }

}
