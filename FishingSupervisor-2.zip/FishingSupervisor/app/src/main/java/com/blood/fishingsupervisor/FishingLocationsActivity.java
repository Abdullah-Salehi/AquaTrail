package com.blood.fishingsupervisor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class FishingLocationsActivity extends AppCompatActivity {

    private ListView mFishingLocationsListView;

    private String[] mFishingLocations = {"Alaska", "Norway", "Japan", "New Zealand", "Canada", "Australia", "Peru"};

    private int[] mFishingLocationsImages = {R.drawable.alaska, R.drawable.norway, R.drawable.japan, R.drawable.newzeland, R.drawable.canada, R.drawable.australia, R.drawable.peru};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fishing_locations);

        mFishingLocationsListView = findViewById(R.id.fishing_locations_list_view);

        ArrayList<Item> items = new ArrayList<Item>();
        for(int i = 0; i < mFishingLocations.length; i++) {
            items.add(new Item(mFishingLocations[i], mFishingLocationsImages[i]));
        }


        CustomAdapter adapter = new CustomAdapter(this, items);
        mFishingLocationsListView.setAdapter(adapter);
    }
}

